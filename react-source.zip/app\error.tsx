"use client"

import RouteState from "../components/RouteState"
import { Button } from "../components/ui"
import { useLanguage } from "../lib/language-context"
import en from "../locales/en.json"
import ar from "../locales/ar.json"

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const copy = useLanguage() === "ar" ? ar : en
  return (
    <RouteState title={copy.errorTitle} description={copy.errorDescription} homeLabel={copy.backHome}>
      <Button onClick={reset}>{copy.retry}</Button>
    </RouteState>
  )
}
