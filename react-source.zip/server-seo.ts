import { headers } from "next/headers"
import { pageMetadata } from "./seo"
import type en from "../locales/en.json"
import type { Dish } from "../data/menu"

export async function requestLocale() {
  return (await headers()).get("x-manara-locale") === "ar" ? "ar" as const : "en" as const
}

export async function routeMetadata(path: string, key: keyof typeof en, dish?: Dish) {
  return pageMetadata(path, key, await requestLocale(), dish)
}
