import { Info } from "lucide-react"
import { site } from "../config/site"
import type { Locale } from "../lib/localized-url"
import en from "../locales/en.json"
import ar from "../locales/ar.json"

export default function KitchenNotice({ lang }: { lang: Locale }) {
  if (!site.foodInformation.enabled || !site.foodInformation.showKitchenNotice) return null
  const copy = lang === "ar" ? ar : en
  return (
    <aside role="note" aria-label={copy.foodKitchenTitle} className="kitchen-notice my-5 flex items-start gap-3 rounded-xl border border-brand/15 bg-brand/5 p-4 text-sm text-ink">
      <Info size={20} className="text-brand" aria-hidden="true" />
      <div className="grid gap-2">
        <b>{copy.foodKitchenTitle}</b>
        <span>{copy.foodKitchenNotice}</span>
      </div>
    </aside>
  )
}
