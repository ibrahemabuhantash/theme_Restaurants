"use client"

import RouteState from "../components/RouteState"
import { Button } from "../components/ui"
import en from "../locales/en.json"

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en"><body>
      <RouteState title={en.errorTitle} description={en.errorDescription} homeLabel={en.backHome}>
        <Button onClick={reset}>{en.retry}</Button>
      </RouteState>
    </body></html>
  )
}
