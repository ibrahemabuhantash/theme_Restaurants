import type { MetadataRoute } from "next"
import { absoluteUrl, canIndex, privatePaths } from "../lib/seo"

export default function robots(): MetadataRoute.Robots {
  return {
    rules: canIndex()
      ? { userAgent: "*", allow: "/", disallow: privatePaths.flatMap((path) => [path, `/ar${path}`]) }
      : { userAgent: "*", disallow: "/" },
    sitemap: absoluteUrl("/sitemap.xml"),
  }
}
