import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/checkout", "checkout")
}

export default function Page() {
  return <InteractivePage />
}
