import RouteState from "../components/RouteState"
import LocalizedContent from "../components/LocalizedContent"
import en from "../locales/en.json"
import ar from "../locales/ar.json"

export default function NotFound() {
  return <LocalizedContent
    english={<RouteState title={en.notFound} description={en.notFoundDescription} homeLabel={en.backHome} />}
    arabic={<RouteState title={ar.notFound} description={ar.notFoundDescription} homeLabel={ar.backHome} />}
  />
}
