import RouteState from "../components/RouteState"
import LocalizedContent from "../components/LocalizedContent"
import en from "../locales/en.json"
import ar from "../locales/ar.json"

export default function Loading() {
  return <div role="status" aria-live="polite"><LocalizedContent
    english={<RouteState title={en.loading} description={en.loadingDescription} />}
    arabic={<RouteState title={ar.loading} description={ar.loadingDescription} />}
  /></div>
}
