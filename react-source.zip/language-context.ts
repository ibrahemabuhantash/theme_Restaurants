"use client"

import { createContext, useContext } from "react"
import type { Locale } from "./localized-url"

export const LanguageContext = createContext<Locale>("en")

export function useLanguage() {
  return useContext(LanguageContext)
}
