import JsonLd from "./JsonLd"
import { requestLocale } from "../lib/server-seo"
import { breadcrumbSchema, menuSchema, productSchema, restaurantSchema, reviewSchema } from "../lib/seo"
import type { Dish } from "../data/menu"
import type en from "../locales/en.json"

export default async function PageSeo({ path, pageKey, dish }: {
  path: string
  pageKey: keyof typeof en
  dish?: Dish
}) {
  const locale = await requestLocale()
  const nodes = [breadcrumbSchema(path, pageKey, locale, dish)]
  if (path === "/" || path === "/contact") nodes.push(...restaurantSchema(locale))
  if (path === "/") nodes.push(...reviewSchema(locale))
  if (path === "/menu") nodes.push(menuSchema(locale))
  if (dish) nodes.push(productSchema(dish, locale))
  return <JsonLd nodes={nodes} />
}
