import { Info, Flame, Leaf, ShieldCheck } from "lucide-react"
import { site } from "../config/site"
import type { FoodInformation as Information } from "../data/menu"
import { visibleFoodInformation } from "../lib/food-information"
import type { Locale } from "../lib/localized-url"
import en from "../locales/en.json"
import ar from "../locales/ar.json"
import { Heading } from "./ui"

export default function FoodInformation({
  information, lang, compact = false,
}: { information?: Information; lang: Locale; compact?: boolean }) {
  const info = visibleFoodInformation(information, site.foodInformation.enabled)
  if (!info) return null
  const copy = lang === "ar" ? ar : en
  return (
    <section
      className={compact ? "food-information mt-3 grid gap-2 text-xs" : "food-information my-5 grid gap-3 rounded-xl border border-brand/15 bg-brand/5 p-4 text-sm"}
      aria-label={copy.foodInformationTitle}
    >
      {!compact && <Heading as="h3">{copy.foodInformationTitle}</Heading>}
      <div className="flex flex-wrap items-center gap-2">
        {info.calories !== undefined && (
          <span className="rounded-full bg-paper px-3 py-1 text-ink">
            {new Intl.NumberFormat(lang === "ar" ? "ar-JO" : "en-JO").format(info.calories)} {copy.foodCaloriesUnit}
          </span>
        )}
        {info.dietary?.map((tag) => {
          const Icon = tag === "spicy" ? Flame : tag === "halal" ? ShieldCheck : Leaf
          return (
            <span key={tag} className="inline-flex items-center gap-1 rounded-full bg-brand/10 px-3 py-1 text-brand">
              <Icon size={14} aria-hidden="true" />
              {copy[`foodDiet_${tag}`]}
            </span>
          )
        })}
      </div>
      {info.allergens && (
        <div className="flex flex-wrap gap-x-2 gap-y-1 text-ink">
          <b>{copy.foodContains}</b>
          <span>{info.allergens.map((allergen) => copy[`foodAllergen_${allergen}`]).join(" · ")}</span>
        </div>
      )}
      {!compact && <div className="text-xs text-ink">{copy.foodServingNote}</div>}
      {info.demo && (
        <div className="flex items-start gap-2 text-xs text-ink">
          <Info size={14} aria-hidden="true" />
          <span>{copy.foodDemoNote}</span>
        </div>
      )}
    </section>
  )
}
