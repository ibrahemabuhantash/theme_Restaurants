import PageSeo from "../../components/PageSeo"
import { routeMetadata } from "../../lib/server-seo"
import LocalizedContent from "../../components/LocalizedContent"
import LegalContent from "../../components/LegalContent"

export async function generateMetadata() {
  return routeMetadata("/privacy", "privacy")
}

export default function Page() {
  return <><PageSeo path="/privacy" pageKey="privacy" /><LocalizedContent english={<LegalContent kind="privacy" lang="en" />} arabic={<LegalContent kind="privacy" lang="ar" />} /></>
}
