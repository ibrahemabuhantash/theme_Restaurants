import { Heading } from "./ui"
import { legal } from "../data/legal"

export default function LegalContent({ kind, lang }: { kind: keyof typeof legal; lang: "en" | "ar" }) {
  const copy = legal[kind][lang]
  return (
    <section className="container section legal">
      <Heading as="h1">{copy.title}</Heading>
      {copy.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
    </section>
  )
}
