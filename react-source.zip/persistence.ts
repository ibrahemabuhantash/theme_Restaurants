"use client"

import { useEffect, useState, type Dispatch, type SetStateAction } from "react"

/** Server and first client render use the same fallback; storage is read after mount. */
export function usePersistentState<T>(
  key: string,
  fallback: T,
  validate: (value: unknown) => value is T,
): [T, Dispatch<SetStateAction<T>>, boolean] {
  const [value, setValue] = useState<T>(fallback)
  const [ready, setReady] = useState(false)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(key)
      const restored: unknown = raw ? JSON.parse(raw) : null
      if (validate(restored)) setValue(restored)
    } catch {
      // Storage may be unavailable or corrupted. Continue as an in-memory demo.
    }
    setReady(true)
    // Validation/fallback are initializers, not subscriptions.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key])
  useEffect(() => {
    if (!ready) return
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch {
      // Keep controls usable when storage is denied or full.
    }
  }, [key, ready, value])
  return [value, setValue, ready]
}
