import { Clock3, MapPin } from "lucide-react"
import type { DeliveryZone } from "../config/branches"
import { roundMoney } from "../lib/delivery"
import type { Locale } from "../lib/localized-url"
import en from "../locales/en.json"
import ar from "../locales/ar.json"

export default function DeliveryDetails({ zone, orderValue, lang, money }: {
  zone: DeliveryZone
  orderValue: number
  lang: Locale
  money: (value: number) => string
}) {
  const copy = lang === "ar" ? ar : en
  const remaining = zone.freeDeliveryAbove === undefined ? undefined
    : roundMoney(Math.max(0, zone.freeDeliveryAbove - orderValue))
  return (
    <div className="delivery-details wide grid gap-3 rounded-xl border border-brand/15 bg-brand/5 p-4 text-sm text-ink" role="status" aria-live="polite">
      <b className="flex items-center gap-2"><MapPin size={16} aria-hidden="true" />{zone.name[lang]}</b>
      <div className="flex flex-wrap gap-x-4 gap-y-2">
        <span>{copy.zoneDeliveryFee}: {money(zone.fee)}</span>
        <span>{copy.minimumOrder}: {money(zone.minimumOrder)}</span>
      </div>
      <span className="flex items-center gap-2">
        <Clock3 size={16} aria-hidden="true" />
        {copy.estimatedDelivery}: {zone.estimatedMinutes.join("–")} {copy.deliveryMinutes}
      </span>
      {zone.freeDeliveryAbove !== undefined && (
        <span>{copy.freeDeliveryThreshold.replace("{amount}", money(zone.freeDeliveryAbove))}</span>
      )}
      {remaining !== undefined && (
        <b>{remaining === 0 ? copy.freeDeliveryUnlocked : copy.freeDeliveryRemaining.replace("{amount}", money(remaining))}</b>
      )}
      <span className="text-xs">{copy.deliveryThresholdBasis}</span>
      <span className="text-xs">{copy.deliveryMockNotice}</span>
    </div>
  )
}
