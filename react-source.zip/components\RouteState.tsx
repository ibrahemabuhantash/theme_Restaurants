import NextLink from "next/link"
import { Heading } from "./ui"

export default function RouteState({
  title, description, homeLabel, children,
}: {
  title: string
  description: string
  homeLabel?: string
  children?: React.ReactNode
}) {
  return (
    <section className="container section empty">
      <Heading as="h1">{title}</Heading>
      <p>{description}</p>
      {children}
      {homeLabel && <NextLink href="/" className="btn btn-outline">{homeLabel}</NextLink>}
    </section>
  )
}
