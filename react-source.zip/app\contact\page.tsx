import PageSeo from "../../components/PageSeo"
import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/contact", "contact")
}

export default function Page() {
  return <><PageSeo path="/contact" pageKey="contact" /><InteractivePage /></>
}
