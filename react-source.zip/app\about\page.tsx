import PageSeo from "../../components/PageSeo"
import { routeMetadata } from "../../lib/server-seo"
import LocalizedContent from "../../components/LocalizedContent"
import StoryContent from "../../components/StoryContent"

export async function generateMetadata() {
  return routeMetadata("/about", "about")
}

export default function Page() {
  return <><PageSeo path="/about" pageKey="about" /><LocalizedContent english={<StoryContent lang="en" />} arabic={<StoryContent lang="ar" />} /></>
}
