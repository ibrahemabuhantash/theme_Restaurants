import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/reset-password", "resetPassword")
}

export default function Page() {
  return <InteractivePage />
}
