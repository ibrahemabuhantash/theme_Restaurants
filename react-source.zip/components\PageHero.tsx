import type { ImageAsset } from "../config/images"
import Image from "./Image"
import { Heading } from "./ui"

export default function PageHero({
  title, sub, eyebrow, image, lang,
}: {
  title: string
  sub?: string
  eyebrow?: string
  image: ImageAsset
  lang: "en" | "ar"
}) {
  return (
    <section className="page-hero">
      <Image asset={image} lang={lang} size="full" decorative loading="eager" />
      <div className="container">
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <Heading as="h1">{title}</Heading>
        {sub && <p>{sub}</p>}
      </div>
    </section>
  )
}
