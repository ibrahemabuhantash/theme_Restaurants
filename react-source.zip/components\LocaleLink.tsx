"use client"

import NextLink from "next/link"
import type { ComponentProps } from "react"
import { localizedPath, type Locale } from "../lib/localized-url"

export default function LocaleLink({
  locale, href, ...props
}: Omit<ComponentProps<typeof NextLink>, "href"> & { href: string; locale: Locale }) {
  return <NextLink {...props} href={href.startsWith("/") ? localizedPath(href, locale) : href} />
}
