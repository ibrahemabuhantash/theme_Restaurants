import PageSeo from "../../components/PageSeo"
import { routeMetadata } from "../../lib/server-seo"
import LocalizedContent from "../../components/LocalizedContent"
import LegalContent from "../../components/LegalContent"

export async function generateMetadata() {
  return routeMetadata("/terms", "terms")
}

export default function Page() {
  return <><PageSeo path="/terms" pageKey="terms" /><LocalizedContent english={<LegalContent kind="terms" lang="en" />} arabic={<LegalContent kind="terms" lang="ar" />} /></>
}
