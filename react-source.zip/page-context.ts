"use client"

import { createContext, type ReactNode } from "react"

export const PageContext = createContext<(() => ReactNode) | null>(null)
