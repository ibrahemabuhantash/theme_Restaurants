import type { Metadata } from "next"
import App from "../App"
import { site } from "../config/site"
import { requestLocale } from "../lib/server-seo"
import "../index.css"

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: site.name, template: `%s | ${site.name}` },
  description: site.seo.description.en,
  icons: { icon: site.logo.src },
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await requestLocale()
  return (
    <html lang={locale} dir={locale === "ar" ? "rtl" : "ltr"}>
      <body><App initialLocale={locale}>{children}</App></body>
    </html>
  )
}
