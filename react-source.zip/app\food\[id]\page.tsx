import { routeMetadata } from "../../../lib/server-seo"
import PageSeo from "../../../components/PageSeo"
import { notFound } from "next/navigation"
import InteractivePage from "../../../components/InteractivePage"
import { dishes } from "../../../data/menu"

export const dynamicParams = false

export function generateStaticParams() {
  return dishes.map((dish) => ({ id: String(dish.id) }))
}
export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const dish = dishes.find((item) => item.id === Number(id))
  if (!dish || !/^\d+$/.test(id)) notFound()
  return routeMetadata(`/food/${dish.id}`, "menu", dish)
}
export default async function DishPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  if (!/^\d+$/.test(id) || !dishes.some((dish) => dish.id === Number(id))) notFound()
  const dish = dishes.find((item) => item.id === Number(id))!
  return <><PageSeo path={`/food/${dish.id}`} pageKey="menu" dish={dish} /><InteractivePage /></>
}
