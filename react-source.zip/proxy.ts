import { NextResponse, type NextRequest } from "next/server"
import { dishes } from "./data/menu"
import { localeFromPath, unlocalizedPath } from "./lib/localized-url"

/** Reject unknown dish URLs before the loading boundary can stream a 200. */
export function proxy(request: NextRequest) {
  const path = unlocalizedPath(request.nextUrl.pathname)
  const headers = new Headers(request.headers)
  headers.set("x-manara-locale", localeFromPath(request.nextUrl.pathname))
  headers.set("x-manara-path", path)
  const match = /^\/food\/(\d+)\/?$/.exec(path)
  if (path.startsWith("/food/") && (!match || !dishes.some((dish) => dish.id === Number(match[1])))) {
    return NextResponse.rewrite(new URL("/missing-dish", request.url), { status: 404 })
  }
  if (localeFromPath(request.nextUrl.pathname) === "ar") {
    const url = request.nextUrl.clone()
    url.pathname = path
    return NextResponse.rewrite(url, { request: { headers } })
  }
  return NextResponse.next({ request: { headers } })
}

export const config = {
  matcher: ["/((?!_next|api|sitemap.xml|robots.txt|.*\\.[^/]+$).*)"],
}
