"use client"

import { useContext } from "react"
import { PageContext } from "../lib/page-context"

export default function InteractivePage() {
  const render = useContext(PageContext)
  if (!render) throw new Error("InteractivePage requires the application provider")
  return <>{render()}</>
}
