import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/forgot-password", "forgot")
}

export default function Page() {
  return <InteractivePage />
}
