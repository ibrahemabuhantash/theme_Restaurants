import { serializeJsonLd, type SchemaNode } from "../lib/seo"

export default function JsonLd({ nodes }: { nodes: SchemaNode[] }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: serializeJsonLd(nodes) }} />
}
