import NextLink from "next/link"
import { Leaf, Heart, Utensils } from "lucide-react"
import PageHero from "./PageHero"
import Image from "./Image"
import { Heading } from "./ui"
import { site } from "../config/site"
import { images } from "../config/images"
import { team } from "../data/team"
import en from "../locales/en.json"
import ar from "../locales/ar.json"

export default function StoryContent({ lang }: { lang: "en" | "ar" }) {
  const copy = lang === "ar" ? ar : en
  return (
    <>
      <PageHero title={copy.storyTitle} sub={site.tagline} image={site.interior} lang={lang} eyebrow={copy.pageEyebrow} />
      <section className="container section about-composition">
        <div>
          <div className="eyebrow">{copy.storyLabel}</div>
          <Heading>{copy.mission}</Heading>
          <p>{lang === "en" ? site.story : copy.storyParagraph}</p>
          <p>{copy.storyBelief}</p>
          <div className="values-grid">
            {[{ Icon: Leaf, label: copy.valueFresh }, { Icon: Heart, label: copy.valueHospitality }, { Icon: Utensils, label: copy.valueCare }].map(({ Icon, label }) => (
              <div key={label}><Icon size={24} /><b>{label}</b></div>
            ))}
          </div>
        </div>
        <Image asset={images.kitchen} lang={lang} size="half" />
      </section>
      <section className="container section">
        <div className="section-head"><div><Heading>{copy.team}</Heading><p>{copy.teamSub}</p></div></div>
        <div className="team-grid">{team.map((member) => (
          <article key={member.name}>
            <Image asset={member.image} lang={lang} size="team" />
            <Heading as="h3">{member.name}</Heading><p>{member.role}</p>
          </article>
        ))}</div>
      </section>
      <section className="container reservation-banner">
        <div><Heading>{copy.reserveTitle}</Heading><p>{copy.reserveText}</p></div>
        <NextLink href="/reservation" className="btn btn-primary">{copy.reservation}</NextLink>
      </section>
    </>
  )
}
