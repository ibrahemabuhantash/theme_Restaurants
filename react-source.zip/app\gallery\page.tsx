import PageSeo from "../../components/PageSeo"
import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/gallery", "gallery")
}

export default function Page() {
  return <><PageSeo path="/gallery" pageKey="gallery" /><InteractivePage /></>
}
