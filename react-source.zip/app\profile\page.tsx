import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/profile", "profile")
}

export default function Page() {
  return <InteractivePage />
}
