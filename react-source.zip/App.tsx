"use client"

import { useEffect, useState, Fragment, type FormEvent, type ReactNode, type CSSProperties } from "react"
import { LanguageContext } from "./lib/language-context"
import { PageContext } from "./lib/page-context"
import {
  ArrowRight,
  ArrowUpRight,
  ShoppingBag,
  UserRound,
  Globe2,
  Menu as MenuIcon,
  X,
  Heart,
  Plus,
  Minus,
  Star,
  MapPin,
  Clock3,
  Phone,
  Mail,
  Instagram,
  Facebook,
  Leaf,
  Coffee,
  Utensils,
  Search,
  SlidersHorizontal,
  Trash2,
  ChevronRight,
  Eye,
  EyeOff,
  ShieldCheck,
  Bike,
  CreditCard,
  LogOut,
  CheckCircle2,
  Expand,
} from "lucide-react"
import LocaleLink from "./components/LocaleLink"
import { localizedPath, localeFromPath, unlocalizedPath, type Locale } from "./lib/localized-url"
import { usePathname, useRouter } from "next/navigation"
import { usePersistentState } from "./lib/persistence"
import { cartItems, ids, language, nullableUser, strings, text, ordersList, submissionsList, formFields, type CartItem, type User, type Order, type Submission } from "./lib/models"
import { accountsList, resetRequest, passwordHash, type Account, type ResetRequest } from "./lib/mock-auth"
import * as Dialog from "@radix-ui/react-dialog"
import { site } from "./config/site"
import type { Branch } from "./config/branches"
import { categories, categoryImages } from "./data/categories"
import { reviews, reviewSummary } from "./data/reviews"
import { galleryPreview, galleryPhotos } from "./data/gallery"
import { welcomeOffer } from "./data/offers"
import {
  dishes,
  sizes,
  extras,
  type Dish,
} from "./data/menu"
import { availabilityStatus } from "./data/availability"
import { minimumSelections, validOptionSelections, optionPrice, optionLabels } from "./data/options"
import Image from "./components/Image"
import FoodInformation from "./components/FoodInformation"
import KitchenNotice from "./components/KitchenNotice"
import DeliveryDetails from "./components/DeliveryDetails"
import { deliveryQuote, roundMoney } from "./lib/delivery"
import PageHero from "./components/PageHero"
import { images, type ImageAsset } from "./config/images"
import en from "./locales/en.json"
import ar from "./locales/ar.json"
import { Button, Field, Heading, Select } from "./components/ui"
type DishDraft = {
  qty: number
  size: string
  selected: string[]
  notes: string
  choices: number[][]
}
const emptyDraft = (): DishDraft => ({
  qty: 1, size: "Regular", selected: [], notes: "", choices: [],
})
// Keep this module's exports component-only for Fast Refresh.
export default function App({ children, initialLocale = "en" }: { children: ReactNode; initialLocale?: Locale }) {
  const pathname = usePathname()
  const path = unlocalizedPath(pathname)
  const [lang, setLang] = useState<Locale>(initialLocale)
  const router = useRouter()
  const [, persistLanguage, languageReady] = usePersistentState<"en" | "ar">("manara-language", initialLocale, language)
  const [cart, setCart, cartReady] = usePersistentState<CartItem[]>("manara-cart", [], cartItems)
  const [favorites, setFavorites, favoritesReady] = usePersistentState<number[]>("manara-favorites", [], ids)
  const [user, setUser, userReady] = usePersistentState<User | null>("manara-user", null, nullableUser)
  const [addresses, setAddresses, addressesReady] = usePersistentState<string[]>("manara-addresses", [], strings)
  const [orders, setOrders, ordersReady] = usePersistentState<Order[]>("manara-orders", [], ordersList)
  const [submissions, setSubmissions, submissionsReady] = usePersistentState<Submission[]>("manara-submissions", [], submissionsList)
  const [accounts, setAccounts, accountsReady] = usePersistentState<Account[]>("manara-accounts", [], accountsList)
  const [reset, setReset, resetReady] = usePersistentState<ResetRequest>("manara-reset", null, resetRequest)
  const [branchId, setBranchId, branchReady] = usePersistentState<string>("manara-branch", site.branches[0]?.id ?? "", text)
  const hydrated = languageReady && cartReady && favoritesReady && userReady && addressesReady && ordersReady && submissionsReady && accountsReady && resetReady && branchReady
  const [authBusy, setAuthBusy] = useState(false)
  const [addressEdit, setAddressEdit] = useState<{ index: number; value: string } | null>(null)
  const [drafts, setDrafts] = useState<Record<number, DishDraft>>({})
  const [mobile, setMobile] = useState(false),
    [toast, setToast] = useState(""),
    [category, setCategory] = useState("All"),
    [search, setSearch] = useState(""),
    [diet, setDiet] = useState(""),
    [sort, setSort] = useState("recommended"),
    [lightbox, setLightbox] = useState<ImageAsset | null>(null),
    [promo, setPromo] = useState(""),
    [discount, setDiscount] = useState(false),
    [pickup, setPickup] = useState(false),
    [success, setSuccess] = useState(""),
    [orderNumber, setOrderNumber] = useState(""),
    [profileTab, setProfileTab] = useState("overview"),
    [passwordVisible, setPasswordVisible] = useState(false),
    [galleryFilter, setGalleryFilter] = useState("All")

  const branches: Branch[] = site.branches
  if (!branches.length)
    throw new Error("Configure at least one branch in src/config/branches.ts")
  const [zoneId, setZoneId] = useState("")
  const [deliveryCity, setDeliveryCity] = useState("")
  const branch = branches.find((b) => b.id === branchId) || branches[0]
  const zone = branch.deliveryZones.find((z) => z.id === zoneId)
  const [availabilityNow, setAvailabilityNow] = useState(() => new Date(0))
  useEffect(() => {
    const refresh = () => setAvailabilityNow(new Date())
    refresh()
    const timer = window.setInterval(refresh, 15000)
    window.addEventListener("focus", refresh)
    return () => {
      window.clearInterval(timer)
      window.removeEventListener("focus", refresh)
    }
  }, [])
  const status = (id: number, now = availabilityNow) =>
    availabilityStatus(dishes.find((d) => d.id === id), branch, now, site.timeZone)
  const available = (id: number) => status(id) === "available"
  const availabilityLabel = (id: number) => {
    const value = status(id)
    return t(value === "sold-out" ? "soldOut" : value === "scheduled" ? "scheduled" : "unavailable")
  }
  const unavailable = cart.some((i) => !available(i.id))
  const changeBranch = (id: string) => {
    setBranchId(id)
    setZoneId("")
  }
  const t = (key: string) =>
    (lang === "ar" ? ar : en)[(key as keyof typeof en)] || key
  const money = (n: number) =>
    new Intl.NumberFormat(lang === "ar" ? "ar-JO" : "en-JO", {
      style: "currency",
      currency: site.currency,
      minimumFractionDigits: 3,
      maximumFractionDigits: 3,
    }).format(n)
  useEffect(() => {
    const locale = localeFromPath(pathname)
    setLang(locale)
    persistLanguage(locale)
  }, [pathname, persistLanguage])
  const navigate = (p: string) => {
    router.push(localizedPath(p, lang))
    setMobile(false)
    setSuccess("")
  }
  useEffect(() => {
    setMobile(false)
    setSuccess("")
    window.requestAnimationFrame(() => document.querySelector<HTMLElement>("#main")?.focus())
  }, [path])
  useEffect(() => {
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"
    document.documentElement.lang = lang
  }, [lang])
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(""), 3500)
      return () => clearTimeout(timer)
    }
  }, [toast])
  const notify = (s: string) => setToast(s)
  const add = (
    d: Dish,
    qty = 1,
    size = "Regular",
    selected: string[] = [],
    notes = "",
    choices: number[][] = [],
  ) => {
    if (status(d.id, new Date()) !== "available") {
      notify(t("branchUnavailable"))
      return
    }
    if (d.optionGroups && !validOptionSelections(d.optionGroups, choices)) {
      notify(t("chooseOptions"))
      navigate(`/food/${d.id}`)
      return
    }
    const normalizedChoices = choices.map((group) => [...group].sort((a, b) => a - b))
    const price = d.optionGroups
      ? d.price + optionPrice(d.optionGroups, normalizedChoices)
      : d.price +
      (sizes.find((s) => s.name === size)?.price || 0) +
      selected.reduce(
        (a, n) => a + (extras.find((e) => e.name === n)?.price || 0),
        0,
      )
    const key = d.optionGroups
      ? JSON.stringify([d.id, normalizedChoices, notes])
      : `${d.id}-${size}-${[...selected].sort().join(",")}-${notes}`
    setCart((c) =>
      c.some((i) => i.key === key)
        ? c.map((i) => (i.key === key ? { ...i, qty: Math.min(99, i.qty + qty) } : i))
        : [...c, { key, id: d.id, qty, price, dish: d, size: d.optionGroups ? "" : size,
            extras: d.optionGroups ? [] : selected, notes,
            ...(d.optionGroups ? { optionSelections: normalizedChoices,
              optionLabels: optionLabels(d.optionGroups, normalizedChoices) } : {}),
          }],
    )
    notify(
      lang === "ar" ? "تمت الإضافة إلى السلة" : `${d.name} added to your cart`,
    )
  }
  const favorite = (id: number) =>
    setFavorites((f) =>
      f.includes(id) ? f.filter((n) => n !== id) : [...f, id],
    )
  const count = cart.reduce((a, i) => a + i.qty, 0),
    subtotal = cart.reduce((a, i) => a + i.qty * i.price, 0),
    discountedSubtotal = roundMoney(subtotal - (discount ? subtotal * welcomeOffer.discount : 0))
  const quote = deliveryQuote({ branch, zoneId, city: deliveryCity, orderValue: discountedSubtotal, pickup })
  const fee = quote.fee ?? 0
  const total = roundMoney(discountedSubtotal + fee)
  const invalidCartOptions = cart.some((item) => {
    const groups = dishes.find((dish) => dish.id === item.id)?.optionGroups
    return groups && !validOptionSelections(groups, item.optionSelections ?? [])
  })
  const cartOptions = (item: CartItem) => item.optionLabels
    ? item.optionLabels.map((label) => label[lang]).join(" · ")
    : [item.size, ...item.extras].filter(Boolean).join(" · ")
  const checkoutError = invalidCartOptions ? t("cartOptionsInvalid") : unavailable
    ? t("branchUnavailable")
    : quote.reason === "minimumOrder"
      ? `${t("minimumOrder")}: ${money(quote.minimumOrder)}`
      : quote.reason ? t(quote.reason) : ""
  const branchSelector = (compact = false) => (
    <Select
      className={
        compact
          ? "branch-selector min-w-0 w-28 shrink-0 md:w-36"
          : "branch-selector"
      }
      label={t("branch")}
      value={branch.id}
      onChange={(e) => changeBranch(e.target.value)}
      options={branches.map((b) => ({ value: b.id, label: b.name[lang] }))}
    />
  )
  const branchDetails = () => (
    <div className="grid gap-2">
      {branchSelector()}
      <p>
        {branch.address[lang]} · {branch.phone}
      </p>
      <p>{branch.openingHours[lang]}</p>
      <p>
        {t("pickupMinimum")}: {money(branch.minimumOrder)} · {t("zonePricingNotice")}
      </p>
    </div>
  )
  const name = (d: Pick<Dish, "name" | "ar">) => (lang === "ar" ? d.ar : d.name)
  const Logo = () => (
    <div className="brand">
      <Image asset={site.logo} lang={lang} size="logo" loading="eager" />
      <div>
        <b>
          {site.name.toLowerCase()}
          <span className="brand-dot">.</span>
        </b>
        <small>RESTAURANT & CAFÉ</small>
      </div>
    </div>
  )
  const sectionHead = (title: string, sub?: string, action?: ReactNode) => (
    <div className="section-head">
      <div>
        <Heading>{title}</Heading>
        {sub && <p>{sub}</p>}
      </div>
      {action}
    </div>
  )
  const Card = ({ dish }: { dish: Dish }) => (
    <article className="dish-card">
      <div className="dish-image">
        <LocaleLink locale={lang} href={`/food/${dish.id}`}>
          <Image asset={dish.image} lang={lang} size="card" />
        </LocaleLink>
        {dish.label && (
          <span
            className={`food-label ${
              dish.label === "Bestseller" ? "blue-label" : ""
            }`}
          >
            {dish.label === "Plant-based" ? <Leaf size={12} /> : null}
            {dish.label}
          </span>
        )}
        <Button
          variant="ghost"
          className={`favorite ${
            favorites.includes(dish.id) ? "is-favorite" : ""
          }`}
          aria-label={`Save ${name(dish)}`}
          aria-pressed={favorites.includes(dish.id)}
          onClick={() => favorite(dish.id)}
        >
          <Heart
            size={17}
            fill={favorites.includes(dish.id) ? "currentColor" : "none"}
          />
        </Button>
      </div>
      <div className="dish-body">
        <LocaleLink locale={lang} href={`/food/${dish.id}`}>
          <Heading as="h3">{name(dish)}</Heading>
        </LocaleLink>
        <p>{lang === "ar" ? dish.descriptionAr : dish.description}</p>
        <FoodInformation information={dish.foodInfo} lang={lang} compact />
        <div className="dish-bottom">
          <b>{money(dish.price)}</b>
          <Button
            variant="outline"
            disabled={!available(dish.id)}
            onClick={() => dish.optionGroups?.length ? navigate(`/food/${dish.id}`) : add(dish)}
          >
            <Plus size={15} />
            {available(dish.id) ? (dish.optionGroups?.length ? t("customize") : t("add")) : availabilityLabel(dish.id)}
          </Button>
        </div>
      </div>
    </article>
  )
  const cards = (list: Dish[]) => (
    <div className="dish-grid">
      {list
        .filter((d) => status(d.id) !== "unavailable")
        .map((d) => (
          <Fragment key={d.id}>{Card({ dish: d })}</Fragment>
        ))}
    </div>
  )
  const formSubmit = (e: FormEvent<HTMLFormElement>, s: string) => {
    e.preventDefault()
    const fields = formFields(e.currentTarget)
    setSubmissions((entries) => [{ id: crypto.randomUUID(), kind: s, branchId: branch.id, date: new Date().toISOString(), fields }, ...entries])
    setSuccess(s)
  }
  const Reservation = () =>
    success === "reservation" ? (
      Success({ text: `${t("reservationSuccess")} ${t("demoSaved")}` })
    ) : (
      <form
        className="panel form-grid"
        onSubmit={(e) => formSubmit(e, "reservation")}
      >
        <Field label={t("name")} required name="name" autoComplete="name" />
        <Field label={t("phone")} required type="tel" name="phone" />
        <Field label={t("email")} required type="email" name="email" />
        <Field
          label={t("date")}
          required
          type="date"
          min={new Date().toISOString().slice(0, 10)}
          name="date"
        />
        <label className="field">
          <span>{t("time")}</span>
          <select required name="time" aria-label={t("time")} defaultValue="">
            <option value="" disabled>
              Select a time
            </option>
            {[
              "09:00",
              "12:00",
              "13:00",
              "18:00",
              "19:00",
              "20:00",
              "21:00",
            ].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </label>
        <Field
          label={t("guests")}
          required
          type="number"
          min={1}
          max={20}
          defaultValue={2}
        />
        <label className="field wide">
          <span>{t("requests")}</span>
          <textarea name="requests" placeholder="Anything we should know?" rows={3} />
        </label>
        <Button className="wide" type="submit">
          {t("submitReservation")}
          <ArrowRight size={17} />
        </Button>
        <small className="wide muted center">
          Your reservation is confirmed instantly. No deposit required.
        </small>
      </form>
    )
  function Success({ text }: { text: string }) {
    return (
      <div className="success panel">
        <span className="success-icon">
          <CheckCircle2 size={38} />
        </span>
        <Heading as="h1">{t("success")}</Heading>
        <p>{text}</p>
        {orderNumber && success === "order" && (
          <>
            <b>Order #{orderNumber}</b>
            <p>
              {orders[0]?.branchName?.[lang]} ·{" "}
              {orders[0]?.branchAddress?.[lang]}
            </p>
            {orders[0]?.estimatedDeliveryMinutes && (
              <p>{t("estimatedDelivery")}: {orders[0].estimatedDeliveryMinutes.join("–")} {t("deliveryMinutes")}</p>
            )}
            <div className="order-confirm">
              {orders[0]?.items.map((i: CartItem) => (
                <div key={i.key}>
                  {i.qty} × {(i.dish ? name(i.dish) : dishes.find((d) => d.id === i.id) ? name(dishes.find((d) => d.id === i.id)!) : t("removedDish"))}
                  <small>{cartOptions(i)}</small>
                  <b>{money(i.price * i.qty)}</b>
                </div>
              ))}
              <hr />
              <div>
                {t("total")}
                <b>{money(orders[0]?.total || 0)}</b>
              </div>
            </div>
          </>
        )}
        <Button onClick={() => navigate("/")}>
          {t("backHome")}
          <ArrowRight size={16} />
        </Button>
      </div>
    )
  }
  const Home = () => (
    <>
      <section className="hero container">
        <div className="hero-copy">
          <div className="eyebrow">
            <span /> {t("eyebrow")}
          </div>
          <Heading as="h1">
            {t("hero1")}
            <br />
            <span>{t("hero2")}</span>
          </Heading>
          <p>{t("heroDescription")}</p>
          <div className="hero-actions">
            <Button onClick={() => navigate("/menu")}>
              {t("explore")}
              <ArrowUpRight size={18} />
            </Button>
            <Button variant="outline" onClick={() => navigate("/reservation")}>
              {t("reservation")}
            </Button>
          </div>
          <div className="hero-proof">
            <div className="avatar-stack">
              {images.guests.map((asset) => (
                <Image key={asset.src} asset={asset} lang={lang} size="avatar" decorative />
              ))}
            </div>
            <div>
              <div className="stars">
                <Star size={13} fill="currentColor" />
                <Star size={13} fill="currentColor" />
                <Star size={13} fill="currentColor" />
                <Star size={13} fill="currentColor" />
                <Star size={13} fill="currentColor" />
                <b>{reviewSummary.rating}</b>
              </div>
              <small>{t("guestLove").replace("{count}", reviewSummary.guestCount)}</small>
            </div>
          </div>
        </div>
        <div className="hero-visual">
          <Image className="hero-photo" asset={site.hero} lang={lang} size="half" loading="eager" fetchPriority="high" />
          <div className="hero-photo-shade" />
          <div className="photo-caption">
            <span>FRESH. SEASONAL. FULL OF LIFE.</span>
            <span>Made to bring you together.</span>
          </div>
          <div className="fresh-badge">
            <span className="leaf-circle">
              <Leaf size={23} />
            </span>
            <div>
              <b>Fresh is our favorite.</b>
              <small>Real ingredients. Every single day.</small>
            </div>
          </div>
          <span className="hero-photo-tag">
            <Utensils size={14} /> A little Mediterranean magic
          </span>
        </div>
      </section>
      <div className="promise-strip container">
        <span>
          <Leaf size={19} />
          Fresh, seasonal ingredients
        </span>
        <i />
        <span>
          <Coffee size={19} />
          Specialty coffee, always
        </span>
        <i />
        <span>
          <Heart size={19} />
          Made with a little extra love
        </span>
        <i />
        <span>
          <ShoppingBag size={19} />
          Dine in, take away, or delivery
        </span>
      </div>
      <section className="section container category-section">
        {sectionHead(t("discover"), t("categoriesSub"))}
        <div className="category-grid">
          {categories.slice(1).map((c, i) => (
            <LocaleLink locale={lang} className="category-card" key={c} href="/menu" onClick={() => setCategory(c)}>
              <div>
                <Image asset={categoryImages[i]} lang={lang} size="category" />
                <div className="category-caption">
                  <b>{t(c)}</b>
                  <ArrowUpRight size={18} />
                </div>
              </div>
            </LocaleLink>
          ))}
        </div>
      </section>
      <section className="featured-section">
        <div className="section container">
          {sectionHead(
            t("favorites"),
            t("favoritesSub"),
            <Button
              variant="outline"
              onClick={() => {
                setCategory("All")
                navigate("/menu")
              }}
            >
              {t("allMenu")}
              <ArrowRight size={16} />
            </Button>,
          )}
          {cards(dishes.slice(0, 4))}
        </div>
      </section>
      <section className="section container story-preview">
        <div className="story-photos">
          <Image asset={site.interior} lang={lang} size="half" />
          <div className="story-note">
            <span>Since 2018</span>
            <b>
              A seat at our table.
              <br />A place in our story.
            </b>
          </div>
        </div>
        <div className="story-copy">
          <div className="eyebrow">{t("storyLabel")}</div>
          <Heading>{t("storyTitle")}</Heading>
          <p>
            {lang === "ar"
              ? "المنارة مستوحاة من دفء مطابخ البحر المتوسط. نجمع الناس حول طعام صادق وضيافة من القلب. من قهوة الصباح إلى عشاء يستحق البقاء، هناك دائماً مكان لك على طاولتنا."
              : site.story}
          </p>
          <Button variant="outline" onClick={() => navigate("/about")}>
            {t("storyCta")}
            <ArrowUpRight size={17} />
          </Button>
          <div className="story-signature">Good food. Better company.</div>
        </div>
      </section>
      <section className="container offer-banner">
        <div>
          <span className="eyebrow">A LITTLE SOMETHING, JUST FOR YOU</span>
          <Heading>{t(welcomeOffer.titleKey)}</Heading>
          <p>{t(welcomeOffer.descriptionKey)}</p>
          <Button onClick={() => navigate("/menu")}>
            {t("order")}
            <ArrowUpRight size={17} />
          </Button>
        </div>
        <div className="offer-code">
          <span>YOUR FIRST ORDER</span>
          <b>
            {Math.round(welcomeOffer.discount * 100)}<span>%</span> {t("off")}
          </b>
          <small>
            {t("useCode")} <strong>{welcomeOffer.code}</strong> {t("atCheckout")}
          </small>
        </div>
        <Image asset={welcomeOffer.image} lang={lang} size="promo" />
      </section>
      <section className="section container">
        {sectionHead(
          t("galleryTitle"),
          t("gallerySub"),
          <Button variant="ghost" onClick={() => navigate("/gallery")}>
            Explore our gallery
            <ArrowUpRight size={17} />
          </Button>,
        )}
        <div className="gallery-preview">
          {galleryPreview.map((asset, i) => (
            <button key={asset.src} onClick={() => setLightbox(asset)} aria-label={`Open gallery photo ${i + 1}`}>
              <Image asset={asset} lang={lang} size="gallery" />
              <span><Plus /></span>
            </button>
          ))}
        </div>
      </section>
      <section className="reviews-section">
        <div className="container section">
          {sectionHead(t("reviews"), t("reviewSub"))}
          <div className="review-grid">
            {reviews.map((r) => (
              <article className="review-card" key={r.name}>
                <div className="stars">
                  {Array.from({ length: r.rating }, (_, i) => (
                    <Star key={i} size={14} fill="currentColor" />
                  ))}
                </div>
                <p>
                  “
                  {r.text[lang]}
                  ”
                </p>
                <div className="review-author">
                  <span>{r.initials}</span>
                  <div>
                    <b>{r.name}</b>
                    <small>{t("verifiedGuest")}</small>
                  </div>
                  <span className="google-g">G</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="container reservation-banner">
        <div>
          <span className="eyebrow">MAKE TIME FOR GOOD TIMES</span>
          <Heading>{t("reserveTitle")}</Heading>
          <p>{t("reserveText")}</p>
        </div>
        <Button onClick={() => navigate("/reservation")}>
          {t("reservation")}
          <ArrowUpRight size={18} />
        </Button>
        <div className="banner-orbit" />
      </section>
      <section className="section container visit-section">
        <div>
          {sectionHead(t("visit"), t("visitSub"))}
          <div className="contact-row">
            <MapPin />
            <div>
              <b>Find us here</b>
              <p>{branch.address[lang]}</p>
            </div>
          </div>
          <div className="contact-row">
            <Clock3 />
            <div>
              <b>Our doors are open</b>
              <p>{branch.openingHours[lang]}</p>
            </div>
          </div>
          <div className="contact-row">
            <Phone />
            <div>
              <b>Say hello</b>
              <p>{branch.phone}</p>
            </div>
          </div>
          <Button variant="outline" onClick={() => navigate("/contact")}>
            Get in touch
            <ArrowUpRight size={16} />
          </Button>
        </div>
        {MapPreview()}
      </section>
    </>
  )
  function MapPreview() {
    return (
      <div
        className="map-preview"
        aria-label={`Map preview of ${branch.address[lang]}`}
      >
        <div className="map-water" />
        <div className="map-road road-1" />
        <div className="map-road road-2" />
        <div className="map-road road-3" />
        <span className="map-label label-1">{branch.name[lang]}</span>
        <span className="map-label label-2">{branch.address[lang]}</span>
        <span className="map-pin">
          <Image asset={site.logo} lang={lang} size="logo" />
        </span>
        <a
          href={`https://maps.google.com/?q=${branch.coordinates.lat},${branch.coordinates.lng}`}
          target="_blank"
          rel="noreferrer"
          className="map-link"
        >
          Open in Google Maps
          <ArrowUpRight size={15} />
        </a>
      </div>
    )
  }
  const MenuPage = () => {
    let filtered = dishes.filter(
      (d) =>
        status(d.id) !== "unavailable" &&
        (category === "All" || d.category === category) &&
        `${d.name} ${d.ar} ${d.description}`
          .toLowerCase()
          .includes(search.toLowerCase()) &&
        (!diet || d.label === diet),
    )
    if (sort !== "recommended")
      filtered = [...filtered].sort((a, b) =>
        sort === "low" ? a.price - b.price : b.price - a.price,
      )
    return (
      <>
        <PageHero lang={lang} eyebrow={t("pageEyebrow")} image={site.hero} title={t("menu")} sub={t("categoriesSub")} />
        <section className="section container">
          <KitchenNotice lang={lang} />
          <div className="menu-tools">
            <div className="search-field">
              <Search size={19} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t("search")}
                aria-label={t("search")}
              />
              {search && (
                <button onClick={() => setSearch("")} aria-label="Clear search">
                  <X size={16} />
                </button>
              )}
            </div>
            <label className="select-control">
              <SlidersHorizontal size={16} />
              <select
                value={diet}
                onChange={(e) => setDiet(e.target.value)}
                aria-label="Dietary preferences"
              >
                <option value="">{t("filter")}</option>
                <option>Vegetarian</option>
                <option>Plant-based</option>
              </select>
            </label>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              aria-label="Sort menu"
            >
              <option value="recommended">{t("sort")}</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
            </select>
          </div>
          <div className="chips">
            {categories.map((c) => (
              <Button
                variant={category === c ? "primary" : "outline"}
                key={c}
                onClick={() => setCategory(c)}
              >
                {t(c)}
              </Button>
            ))}
          </div>
          <div className="menu-count">
            {filtered.length} delicious possibilities
          </div>
          {filtered.length ? (
            cards(filtered)
          ) : (
            <div className="empty">
              <Search size={40} />
              <Heading>No dishes found</Heading>
              <p>Try another search or category.</p>
              <Button
                onClick={() => {
                  setSearch("")
                  setDiet("")
                  setCategory("All")
                }}
              >
                Clear filters
              </Button>
            </div>
          )}
        </section>
      </>
    )
  }
  function FoodPage({ dish }: { dish: Dish }) {
    const { qty, size, selected, notes, choices } = drafts[dish.id] ?? emptyDraft()
    const updateDraft = <K extends keyof DishDraft,>(
      key: K, value: DishDraft[K] | ((current: DishDraft[K]) => DishDraft[K]),
    ) => setDrafts((current) => {
      const draft = current[dish.id] ?? emptyDraft()
      return { ...current, [dish.id]: { ...draft, [key]:
        typeof value === "function" ? value(draft[key]) : value } }
    })
    const setQty = (value: number) => updateDraft("qty", value)
    const setSize = (value: string) => updateDraft("size", value)
    const setSelected = (value: string[] | ((current: string[]) => string[])) => updateDraft("selected", value)
    const setNotes = (value: string) => updateDraft("notes", value)
    const setChoices = (value: (current: number[][]) => number[][]) => updateDraft("choices", value)
    const groups = dish.optionGroups
    const optionsValid = !groups || validOptionSelections(groups, choices)
    const unit = groups ? dish.price + optionPrice(groups, choices) :
      dish.price +
      (sizes.find((s) => s.name === size)?.price || 0) +
      selected.reduce(
        (a, n) => a + (extras.find((e) => e.name === n)?.price || 0),
        0,
      )
    return (
      <section className="dish-page">
        <div className="container">
          <div className="dish-breadcrumb">
            <LocaleLink locale={lang} href="/menu" className="back-link">
              <ArrowRight size={16} className={lang === "ar" ? "" : "rotate-180"} aria-hidden="true" />
              {t("backToMenu")}
            </LocaleLink>
            <span aria-hidden="true">/</span>
            <span>{t(dish.category)}</span>
          </div>
        <div className="food-details dish-hero">
          <div className="dish-hero-visual">
            <Button
              variant="ghost"
              className="dish-hero-photo"
              aria-label={t("viewDishPhoto")}
              onClick={() => setLightbox(dish.image)}
            >
              <Image className="detail-image" asset={dish.image} lang={lang} size="half" loading="eager" fetchPriority="high" />
              <span className="dish-photo-category"><Utensils size={14} aria-hidden="true" />{t(dish.category)}</span>
              <span className="dish-photo-expand"><Expand size={18} aria-hidden="true" /><span className="sr-only">{t("viewDishPhoto")}</span></span>
            </Button>
            <div className="dish-photo-caption">
              <span><Heart size={16} aria-hidden="true" />{t("craftedWithCare")}</span>
              <span>{site.name}</span>
            </div>
          </div>
          <div className="dish-hero-content">
            <div className="dish-introduction">
              <div className="eyebrow"><span />{t("fromOurKitchen")}</div>
              <Heading as="h1">{name(dish)}</Heading>
              <p className="dish-description">{lang === "ar" ? dish.descriptionAr : dish.description}</p>
              <div className="dish-price-row">
                <b className="detail-price">{money(unit)}</b>
                <span>{t("perServing")}</span>
              </div>
              <div className="dish-branch-status">
                <span><MapPin size={15} aria-hidden="true" />{branch.name[lang]}</span>
                <span><Clock3 size={15} aria-hidden="true" />{available(dish.id) ? t("availableNow") : availabilityLabel(dish.id)}</span>
              </div>
            </div>
            <div className="dish-customization">
            <div className="dish-customization-heading">
              <Heading as="h2">{t("makeItYours")}</Heading>
              <p>{t("dishCustomizeDescription")}</p>
            </div>
            {groups ? groups.map((group, groupIndex) => {
              const chosen = choices[groupIndex] ?? []
              return (
                <div key={groupIndex} role="group" aria-labelledby={`option-group-${groupIndex}`} className="grid gap-3 mb-5">
                  <div id={`option-group-${groupIndex}`}>
                    <Heading as="h3">{lang === "ar" ? group.ar ?? group.name : group.name}</Heading>
                    <p>{group.required ? t("requiredOption") : t("optionalOption")} · {t("chooseRange")} {minimumSelections(group)}–{group.max}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {group.options.map((option, optionIndex) => (
                      <Button
                        key={optionIndex}
                        type="button"
                        variant={chosen.includes(optionIndex) ? "primary" : "outline"}
                        aria-pressed={chosen.includes(optionIndex)}
                        disabled={!chosen.includes(optionIndex) && group.max !== 1 && chosen.length >= group.max}
                        onClick={() => setChoices((current) => (groups ?? []).map((g, index) => {
                          const selected = current[index] ?? []
                          if (index !== groupIndex) return selected
                          if (selected.includes(optionIndex)) return selected.filter((n) => n !== optionIndex)
                          return g.max === 1 ? [optionIndex] : [...selected, optionIndex]
                        }))}
                      >
                        {lang === "ar" ? option.ar ?? option.name : option.name}
                        {option.price ? ` +${money(option.price)}` : ""}
                      </Button>
                    ))}
                  </div>
                </div>
              )
            }) : <>            <Heading as="h3">{t("size")}</Heading>
            <div className="size-options">
              {sizes.map((s) => (
                <Button
                  variant={s.name === size ? "primary" : "outline"}
                  key={s.name}
                  onClick={() => setSize(s.name)}
                >
                  {s.name}
                  {s.price ? ` +${money(s.price)}` : ""}
                </Button>
              ))}
            </div>
            <Heading as="h3">{t("extras")}</Heading>
            <div className="extra-options">
              {extras.map((e) => (
                <label key={e.name}>
                  <input
                    type="checkbox"
                    checked={selected.includes(e.name)}
                    onChange={() =>
                      setSelected((s) =>
                        s.includes(e.name)
                          ? s.filter((n) => n !== e.name)
                          : [...s, e.name],
                      )
                    }
                  />
                  {e.name}
                  <span>+{money(e.price)}</span>
                </label>
              ))}
            </div>
</>}
            {!optionsValid && <p role="status">{t("chooseOptions")}</p>}
            <label className="field">
              <span>{t("instructions")}</span>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="No onions? Extra love? Let us know."
                rows={2}
              />
            </label>
            <div className="add-detail">
              {Quantity({ qty, onChange: setQty })}
              <Button
                disabled={!available(dish.id) || !optionsValid}
                onClick={() => add(dish, qty, size, selected, notes, choices)}
              >
                <ShoppingBag size={18} />
                {available(dish.id) ? t("add") : availabilityLabel(dish.id)} ·{" "}
                {money(unit * qty)}
              </Button>
              <Button
                variant="outline"
                aria-label={t("saveDish")}
                aria-pressed={favorites.includes(dish.id)}
                onClick={() => favorite(dish.id)}
              >
                <Heart
                  fill={favorites.includes(dish.id) ? "currentColor" : "none"}
                  size={18}
                />
              </Button>
            </div>
            </div>
            <div className="ingredients">
              <b>{t("ingredients")}</b>
              <p>{dish.ingredients.join(" · ")}</p>
            </div>
            <FoodInformation information={dish.foodInfo} lang={lang} />
            <KitchenNotice lang={lang} />
          </div>
        </div>
        <div className="section">
          {sectionHead(t("related"))}
          {cards(dishes.filter((d) => d.id !== dish.id).slice(0, 4))}
        </div>
        </div>
      </section>
    )
  }
  function Quantity({
    qty,
    onChange,
  }: {
    qty: number
    onChange: (n: number) => void
  }) {
    return (
      <div className="quantity">
        <button
          aria-label="Decrease quantity"
          disabled={qty <= 1}
          onClick={() => onChange(qty - 1)}
        >
          <Minus size={14} />
        </button>
        <b>{qty}</b>
        <button
          aria-label="Increase quantity"
          disabled={qty >= 99}
          onClick={() => onChange(Math.min(99, qty + 1))}
        >
          <Plus size={14} />
        </button>
      </div>
    )
  }
  const Summary = ({ checkout = false }: { checkout?: boolean }) => (
    <aside className="panel order-summary">
      <Heading as="h3">Order summary</Heading>
      <p>
        {t("branch")}: {branch.name[lang]}
      </p>
      {checkout &&
        cart.map((i) => (
          <div className="summary-item" key={i.key}>
            <Image asset={dishes.find((d) => d.id === i.id)!.image} lang={lang} size="summary" decorative />
            <span>
              {i.qty} × {(i.dish ? name(i.dish) : dishes.find((d) => d.id === i.id) ? name(dishes.find((d) => d.id === i.id)!) : t("removedDish"))}
                  <small>{cartOptions(i)}</small>
            </span>
            <b>{money(i.qty * i.price)}</b>
          </div>
        ))}
      <div className="summary-row">
        <span>{t("subtotal")}</span>
        <b>{money(subtotal)}</b>
      </div>
      <div className="summary-row">
        <span>{t("delivery")}</span>
        <b data-testid="delivery-fee">{quote.fee === null ? t("deliveryPending") : fee ? money(fee) : t("freeDelivery")}</b>
      </div>
      {!pickup && quote.zone && quote.reason !== "outsideDeliveryArea" && (
        <p>{t("estimatedDelivery")}: {quote.zone.estimatedMinutes.join("–")} {t("deliveryMinutes")}</p>
      )}
      {!pickup && quote.freeDeliveryApplied && <p>{t("freeDeliveryUnlocked")}</p>}
      {discount && (
        <div className="summary-row discount">
          <span>{welcomeOffer.code} ({Math.round(welcomeOffer.discount * 100)}%)</span>
          <b>−{money(subtotal * welcomeOffer.discount)}</b>
        </div>
      )}
      <div className="promo-field">
        <input
          placeholder={t("promo")}
          value={promo}
          onChange={(e) => setPromo(e.target.value)}
          aria-label={t("promo")}
        />
        <Button
          variant="outline"
          onClick={() => {
            if (promo.toUpperCase() === welcomeOffer.code) {
              setDiscount(true)
              notify(t("discountApplied").replace("{percent}", String(Math.round(welcomeOffer.discount * 100))))
            } else notify(t("invalidPromo").replace("{code}", welcomeOffer.code))
          }}
        >
          {t("apply")}
        </Button>
      </div>
      <div className="summary-row total">
        <b>{quote.fee === null ? t("estimatedTotal") : t("total")}</b>
        <b data-testid="order-total">{money(total)}</b>
      </div>
      {!checkout && (
        <Button onClick={() => navigate("/checkout")}>
          {t("proceed")}
          <ArrowRight size={17} />
        </Button>
      )}
      <div className="secure">
        <ShieldCheck size={15} />
        Secure checkout. Freshly prepared.
      </div>
    </aside>
  )
  const Empty = () => (
    <div className="empty">
      <span className="empty-icon">
        <ShoppingBag size={42} />
      </span>
      <Heading>{t("empty")}</Heading>
      <p>{t("emptySub")}</p>
      <Button onClick={() => navigate("/menu")}>
        {t("explore")}
        <ArrowRight size={17} />
      </Button>
    </div>
  )
  const CartPage = () => (
    <section className="section container">
      <div className="eyebrow">A BAG FULL OF GOODNESS</div>
      {sectionHead(t("cart"), `${count} items, freshly made for you`)}
      {!count ? (
        <>{Empty()}</>
      ) : (
        <div className="cart-layout">
          <div>
            {branchDetails()}
            {unavailable && <p role="alert">{t("branchUnavailable")}</p>}
            {invalidCartOptions && <p role="alert">{t("cartOptionsInvalid")}</p>}
            <div className="panel cart-items">
              {cart.map((i) => {
                const d = dishes.find((d) => d.id === i.id)!
                return (
                  <div className="cart-item" key={i.key}>
                    <LocaleLink locale={lang} href={`/food/${d.id}`}>
                      <Image asset={d.image} lang={lang} size="thumbnail" />
                    </LocaleLink>
                    <div className="cart-description">
                      <Heading as="h3">{name(d)}</Heading>
                      {!available(d.id) && <p>{availabilityLabel(d.id)}</p>}
                      <small>
                        {cartOptions(i)}
                      </small>
                      <b>{money(i.price)}</b>
                    </div>
                    {Quantity({ qty: i.qty, onChange: (qty) =>
                      setCart((c) => c.map((x) => x.key === i.key ? { ...x, qty } : x)) })}
                    <b>{money(i.price * i.qty)}</b>
                    <button
                      className="icon-button"
                      aria-label={`Remove ${name(d)}`}
                      onClick={() =>
                        setCart((c) => c.filter((x) => x.key !== i.key))
                      }
                    >
                      <Trash2 size={17} />
                    </button>
                  </div>
                )
              })}
            </div>
            <Button variant="ghost" onClick={() => navigate("/menu")}>
              ← {t("continue")}
            </Button>
          </div>
          {Summary({})}
        </div>
      )}
    </section>
  )
  const CheckoutPage = () =>
    success === "order" ? (
      <section className="container section">
        {Success({ text: t("orderSuccess") })}
      </section>
    ) : !count ? (
      <section className="container section">
        <>{Empty()}</>
      </section>
    ) : (
      <section className="container section">
        {sectionHead(t("checkout"), "One more step to something delicious.")}
        <div className="cart-layout">
          <form
            className="panel checkout-form"
            onSubmit={(e) => {
              e.preventDefault()
              const fields = formFields(e.currentTarget)
              const submittedQuote = deliveryQuote({
                branch, zoneId: fields.deliveryZone ?? "", city: fields.city ?? "",
                orderValue: discountedSubtotal, pickup,
              })
              if (cart.some((i) => status(i.id, new Date()) !== "available") || invalidCartOptions) {
                notify(invalidCartOptions ? t("cartOptionsInvalid") : t("branchUnavailable"))
                return
              }
              if (!submittedQuote.eligible) {
                notify(submittedQuote.reason === "minimumOrder"
                  ? `${t("minimumOrder")}: ${money(submittedQuote.minimumOrder)}`
                  : t(submittedQuote.reason ?? "outsideDeliveryArea"))
                return
              }
              const id = `MN-${crypto.randomUUID().slice(0, 8)}`
              setOrders((o) => [
                {
                  id,
                  date: new Date().toLocaleDateString(),
                  items: cart,
                  total: roundMoney(discountedSubtotal + (submittedQuote.fee ?? 0)),
                  status: "Preparing",
                  branchId: branch.id,
                  branchName: branch.name,
                  branchAddress: branch.address,
                  fulfillment: pickup ? "pickup" : "delivery",
                  deliveryZone: pickup ? null : submittedQuote.zone,
                  deliveryFee: submittedQuote.fee ?? 0,
                  estimatedDeliveryMinutes: submittedQuote.zone?.estimatedMinutes,
                  deliveryCity: pickup ? undefined : fields.city.trim(),
                  deliveryMinimum: submittedQuote.minimumOrder,
                  freeDeliveryApplied: submittedQuote.freeDeliveryApplied,
                  contact: { name: fields.name, email: fields.email, phone: fields.phone },
                  address: pickup ? branch.address[lang] : [fields.address, fields.city, fields.postalCode].filter(Boolean).join(", "),
                  payment: fields.payment,
                  notes: fields.notes,
                },
                ...o,
              ])
              setOrderNumber(id)
              setCart([])
              setSuccess("order")
            }}
          >
            {branchDetails()}
            <Heading as="h3">Contact information</Heading>
            <div className="form-grid">
              <Field label={t("name")} name="name" required defaultValue={user?.name} />
              <Field
                label={t("email")}
                type="email"
                name="email"
                required
                defaultValue={user?.email}
              />
              <Field label={t("phone")} name="phone" required type="tel" />
            </div>
            <Heading as="h3">How would you like your order?</Heading>
            <div className="fulfillment">
              <Button
                type="button"
                variant={!pickup ? "primary" : "outline"}
                onClick={() => setPickup(false)}
              >
                <Bike size={18} />
                {t("delivery")}
              </Button>
              <Button
                type="button"
                variant={pickup ? "primary" : "outline"}
                onClick={() => setPickup(true)}
              >
                <ShoppingBag size={18} />
                {t("pickup")}
              </Button>
            </div>
            {!pickup ? (
              <div className="form-grid">
                <Select
                  className="wide"
                  label={t("deliveryZone")}
                  name="deliveryZone"
                  value={zoneId}
                  required
                  onChange={(e) => setZoneId(e.target.value)}
                  options={[
                    { value: "", label: t("chooseZone") },
                    ...branch.deliveryZones.map((z) => ({
                      value: z.id,
                      label: z.name[lang],
                    })),
                    { value: "__outside__", label: t("outsideDeliveryOption") },
                  ]}
                />
                {zone && <DeliveryDetails zone={zone} orderValue={discountedSubtotal} lang={lang} money={money} />}
                {!branch.deliveryZones.length && (
                  <p role="alert">{t("pickupOnly")}</p>
                )}
                <Field
                  label={t("address")}
                  name="address"
                  required
                  className="wide"
                  placeholder="Street, building, apartment"
                />
                <Field
                  label={t("deliveryCity")} name="city" required
                  value={deliveryCity} onChange={(e) => setDeliveryCity(e.target.value)}
                  placeholder={zone?.cities.join(" / ") ?? t("deliveryCityPlaceholder")}
                  autoComplete="address-level2"
                />
                <Field label="Postal code" name="postalCode" />
              </div>
            ) : (
              <p className="pickup-info">
                <MapPin size={18} />
                {branch.address[lang]}
                <br />
                Ready in approximately 25–35 minutes.
              </p>
            )}
            <Heading as="h3">{t("payment")}</Heading>
            <label className="payment-option">
              <input type="radio" name="payment" defaultChecked value="cash" />
              Cash on {pickup ? "pickup" : "delivery"}
            </label>
            <label className="payment-option">
              <input type="radio" name="payment" value="card" />
              Card at {pickup ? "pickup" : "delivery"}
              <CreditCard size={18} />
            </label>
            <label className="field">
              <span>{t("notes")}</span>
              <textarea
                name="notes"
                rows={3}
                placeholder="Anything you'd like us to know?"
              />
            </label>
            <label className="checkbox-label">
              <input type="checkbox" required />I agree to the{" "}
              <LocaleLink locale={lang} href="/terms">terms of service</LocaleLink>.
            </label>
            {checkoutError && <p role="alert">{checkoutError}</p>}
            <Button type="submit" disabled={!!checkoutError}>
              {t("placeOrder")} · {money(total)}
              <ArrowRight size={16} />
            </Button>
            <small className="muted">
              Demo checkout — no payment will be collected.
            </small>
          </form>
          {Summary({ checkout: true })}
        </div>
      </section>
    )
  const GalleryPage = () => (
    <>
      <PageHero lang={lang} eyebrow={t("pageEyebrow")}
        title={t("galleryTitle")}
        sub={t("gallerySub")}
        image={site.interior}
      />
      <section className="container section">
        <div className="chips">
          {["All", "Food", "Coffee", "Space"].map((c) => (
            <Button
              key={c}
              variant={galleryFilter === c ? "primary" : "outline"}
              onClick={() => setGalleryFilter(c)}
            >
              {t(c)}
            </Button>
          ))}
        </div>
        <div className="masonry">
          {galleryPhotos
            .filter((p) => galleryFilter === "All" || p.cat === galleryFilter)
            .map((p, i) => (
              <button
                key={p.image.src}
                onClick={() => setLightbox(p.image)}
                aria-label={`Open ${p.cat} photo ${i + 1}`}
              >
                <Image asset={p.image} lang={lang} size="gallery" />
                <span>
                  <Plus size={23} />
                </span>
              </button>
            ))}
        </div>
      </section>
    </>
  )
  const ContactPage = ({ reservation = false }: { reservation?: boolean }) => (
    <>
      <PageHero lang={lang} eyebrow={t("pageEyebrow")}
        title={reservation ? t("reservation") : t("contactTitle")}
        sub={
          reservation
            ? t("reserveText")
            : "Good conversations start with hello."
        }
        image={site.interior}
      />
      <section className="container section contact-layout">
        <div>
          <Heading>
            {reservation ? "Make yourself at home." : t("visit")}
          </Heading>
          <p className="muted">
            A question, a special celebration, or just a hello. We’re always
            happy to hear from you.
          </p>
          {[
            { Icon: MapPin, text: branch.address[lang] },
            { Icon: Phone, text: branch.phone },
            { Icon: Mail, text: site.email },
            { Icon: Clock3, text: branch.openingHours[lang] },
          ].map(({ Icon, text }) => (
            <div className="contact-row" key={text}>
              <Icon size={21} />
              <span>{text}</span>
            </div>
          ))}
          <div className="socials">
            <a href={site.instagram} aria-label="Instagram">
              <Instagram size={19} />
            </a>
            <a href={site.facebook} aria-label="Facebook">
              <Facebook size={19} />
            </a>
          </div>
          {MapPreview()}
        </div>
        <div>
          {reservation ? (
            Reservation()
          ) : success === "contact" ? (
            Success({ text: t("demoSaved") })
          ) : (
            <form
              className="panel form-grid"
              onSubmit={(e) => formSubmit(e, "contact")}
            >
              <Heading className="wide">Send a little hello.</Heading>
              <Field label={t("name")} required />
              <Field label={t("email")} required type="email" />
              <Field label={t("phone")} type="tel" name="phone" defaultValue={user?.phone} />
              <Field label="Subject" required />
              <label className="field wide">
                <span>{t("message")}</span>
                <textarea name="message" required rows={6} />
              </label>
              <Button type="submit" className="wide">
                {t("send")}
                <ArrowRight size={16} />
              </Button>
            </form>
          )}
        </div>
      </section>
      {!reservation && (
        <section className="container reservation-banner">
          <div>
            <Heading>{t("reserveTitle")}</Heading>
            <p>{t("reserveText")}</p>
          </div>
          <Button onClick={() => navigate("/reservation")}>
            {t("reservation")}
          </Button>
        </section>
      )}
    </>
  )
  const AuthPage = () => {
    const signup = path === "/signup"
    const forgot = path === "/forgot-password"
    const resetting = path === "/reset-password"
    return (
      <section className="auth-layout">
        <div className="auth-photo">
          <Image asset={site.interior} lang={lang} size="half" decorative loading="eager" />
          <div><Heading>{t("hero1")}<br />{t("hero2")}</Heading><p>{site.tagline}</p></div>
        </div>
        <div className="auth-content">
          {Logo()}
          <Heading as="h1">{t(resetting ? "resetPassword" : forgot ? "forgot" : signup ? "signup" : "login")}</Heading>
          <p className="muted">{t("authDemo")}</p>
          {success === "reset" && reset ? (
            <div className="grid gap-4" role="status">
              <p>{t("resetReady")}</p>
              <LocaleLink locale={lang} className="btn btn-primary" href={`/reset-password?token=${reset.token}`}>{t("completeReset")}</LocaleLink>
            </div>
          ) : (
            <form className="auth-form" onSubmit={async (event) => {
              event.preventDefault()
              if (authBusy) return
              const data = new FormData(event.currentTarget)
              const email = String(data.get("email") ?? reset?.email ?? "").trim().toLowerCase()
              const password = String(data.get("password") ?? "")
              if ((signup || resetting) && password !== data.get("confirm")) { notify(t("passwordMismatch")); return }
              setAuthBusy(true)
              try {
                const account = accounts.find((entry) => entry.email === email)
                if (forgot) {
                  if (!account) { notify(t("invalidLogin")); return }
                  setReset({ email, token: crypto.randomUUID(), expires: Date.now() + 15 * 60 * 1000 })
                  setSuccess("reset")
                  return
                }
                if (resetting) {
                  const token = new URLSearchParams(window.location.search).get("token")
                  if (!reset || !account || reset.token !== token || reset.expires < Date.now()) { notify(t("invalidReset")); return }
                  const salt = crypto.randomUUID()
                  const hash = await passwordHash(password, salt)
                  setAccounts((entries) => entries.map((entry) => entry.email === reset.email ? { ...entry, salt, hash } : entry))
                  setReset(null)
                  setUser(null)
                  notify(t("passwordChanged"))
                  navigate("/login")
                  return
                }
                if (signup) {
                  if (account) { notify(t("accountExists")); return }
                  const salt = crypto.randomUUID()
                  const hash = await passwordHash(password, salt)
                  const created = { name: String(data.get("name")).trim(), email, phone: String(data.get("phone")), salt, hash }
                  setAccounts((entries) => [...entries, created])
                  setUser({ name: created.name, email, phone: created.phone })
                } else {
                  if (!account || await passwordHash(password, account.salt) !== account.hash) { notify(t("invalidLogin")); return }
                  try { sessionStorage.setItem("manara-session", "active") } catch { /* In-memory sign-in still works. */ }
                  setUser({ name: account.name, email, phone: account.phone, sessionOnly: !data.has("remember") })
                }
                navigate("/profile")
              } catch { notify(t("errorDescription")) } finally { setAuthBusy(false) }
            }}>
              {signup && <Field label={t("name")} required name="name" autoComplete="name" />}
              {!resetting && <Field label={t("email")} required name="email" type="email" autoComplete="email" />}
              {signup && <Field label={t("phone")} required name="phone" type="tel" autoComplete="tel" />}
              {!forgot && (
                <div className="field">
                  <label htmlFor="account-password">{t("password")}</label>
                  <div className="password-field">
                    <input id="account-password" name="password" required minLength={8} type={passwordVisible ? "text" : "password"} autoComplete={signup || resetting ? "new-password" : "current-password"} />
                    <Button type="button" variant="ghost" onClick={() => setPasswordVisible((value) => !value)} aria-label={t("togglePassword")} aria-pressed={passwordVisible}>{passwordVisible ? <EyeOff size={18} /> : <Eye size={18} />}</Button>
                  </div>
                </div>
              )}
              {(signup || resetting) && <Field label={t("confirmPassword")} required name="confirm" type={passwordVisible ? "text" : "password"} minLength={8} autoComplete="new-password" />}
              {signup && <label className="checkbox-label"><input type="checkbox" required />{t("agreeToTerms")} <LocaleLink locale={lang} href="/terms">{t("terms")}</LocaleLink></label>}
              {!forgot && !signup && !resetting && <div className="auth-options"><label className="checkbox-label"><input type="checkbox" name="remember" defaultChecked />{t("remember")}</label><LocaleLink locale={lang} href="/forgot-password">{t("forgot")}</LocaleLink></div>}
              <Button type="submit" disabled={authBusy}>{authBusy ? t("working") : t(resetting ? "resetPassword" : forgot ? "resetAction" : signup ? "signupAction" : "loginAction")}<ArrowRight size={17} /></Button>
            </form>
          )}
          {!forgot && !resetting && <>
            <Button className="google-btn" variant="outline" onClick={() => { setUser({ name: t("demoGuestName"), email: "guest@example.com" }); navigate("/profile") }}>{t("demoAccount")}</Button>
            <LocaleLink locale={lang} href={signup ? "/login" : "/signup"}>{t(signup ? "loginAction" : "signupAction")}</LocaleLink>
          </>}
          {(forgot || resetting) && <LocaleLink locale={lang} href="/login">{t("loginAction")}</LocaleLink>}
        </div>
      </section>
    )
  }
  const ProfilePage = () =>
    !user ? (
      <section className="container section">
        <div className="empty">
          <UserRound size={40} />
          <Heading>Your place at the table</Heading>
          <p>Log in to view your orders and favorites.</p>
          <Button onClick={() => navigate("/login")}>{t("loginAction")}</Button>
        </div>
      </section>
    ) : (
      <section className="container section">
        {sectionHead(t("profile"))}
        <div className="profile-layout">
          <aside className="panel profile-sidebar">
            <div className="profile-avatar">
              {user.name.slice(0, 2).toUpperCase()}
            </div>
            <b>{user.name}</b>
            <small>{user.email}</small>
            {[
              "overview",
              "personal",
              "orders",
              "addresses",
              "saved",
              "settings",
            ].map((key) => (
              <button
                className={profileTab === key ? "active" : ""}
                aria-pressed={profileTab === key}
                key={key}
                onClick={() => setProfileTab(key)}
              >
                {key === "overview"
                  ? "Overview"
                  : key === "personal"
                    ? "Personal information"
                    : t(key)}
                <ChevronRight size={15} />
              </button>
            ))}
            <button
              onClick={() => {
                setUser(null)
                navigate("/login")
              }}
            >
              <LogOut size={16} />
              {t("logout")}
            </button>
          </aside>
          <div className="profile-main">
            {profileTab === "overview" ? (
              <>
                <div className="panel">
                  <div className="eyebrow">GOOD TO SEE YOU AGAIN</div>
                  <Heading>Welcome back, {user.name.split(" ")[0]}.</Heading>
                  <p className="muted">
                    A little overview of your Manara moments.
                  </p>
                  <div className="profile-stats">
                    <button onClick={() => setProfileTab("orders")}>
                      <ShoppingBag />
                      <b>{orders.length}</b>
                      <span>{t("orders")}</span>
                    </button>
                    <button onClick={() => setProfileTab("saved")}>
                      <Heart />
                      <b>{favorites.length}</b>
                      <span>{t("saved")}</span>
                    </button>
                    <button onClick={() => setProfileTab("addresses")}>
                      <MapPin />
                      <b>{addresses.length}</b>
                      <span>{t("addresses")}</span>
                    </button>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setProfileTab("personal")}
                  >
                    Edit profile
                    <ArrowRight size={16} />
                  </Button>
                </div>
                <div className="panel">
                  <Heading>{t("submissionHistory")}</Heading>
                  {submissions.map((entry) => <details key={entry.id}><summary>{t(entry.kind === "reservation" ? "reservation" : entry.kind === "contact" ? "contact" : "newsletter")} · {entry.date.slice(0, 10)}</summary><p>{Object.entries(entry.fields).map(([key, value]) => `${key}: ${value}`).join(" · ")}</p></details>)}
                </div>
                <div className="section">
                  {sectionHead("Something you might love")}
                  {cards(dishes.slice(0, 2))}
                </div>
              </>
            ) : profileTab === "personal" ? (
              <form
                className="panel auth-form"
                onSubmit={(e) => {
                  e.preventDefault()
                  const d = new FormData(e.currentTarget)
                  const updated = { ...user, name: String(d.get("name")).trim(), email: String(d.get("email")).trim().toLowerCase(), phone: String(d.get("phone")) }
                  if (accounts.some((account) => account.email === updated.email && account.email !== user.email)) { notify(t("emailUpdated")); return }
                  setAccounts((entries) => entries.map((entry) => entry.email === user.email ? { ...entry, name: updated.name, email: updated.email, phone: updated.phone } : entry))
                  setUser(updated)
                  notify(t("phoneSaved"))
                }}
              >
                <Heading>Personal information</Heading>
                <Field
                  label={t("name")}
                  name="name"
                  defaultValue={user.name}
                  required
                />
                <Field
                  label={t("email")}
                  name="email"
                  type="email"
                  defaultValue={user.email}
                  required
                />
                <Field label={t("phone")} type="tel" name="phone" defaultValue={user?.phone} />
                <Button type="submit">Save changes</Button>
              </form>
            ) : profileTab === "saved" ? (
              <>
                {sectionHead(t("saved"))}
                {favorites.length ? (
                  cards(dishes.filter((d) => favorites.includes(d.id)))
                ) : (
                  <>{Empty()}</>
                )}
              </>
            ) : profileTab === "orders" ? (
              <>
                {sectionHead(t("orders"))}
                {orders.length ? (
                  orders.map((o) => (
                    <details className="panel order-history" key={o.id}>
                      <summary>
                        <div>
                          <b>#{o.id}</b>
                          <small>
                            {o.date} · {o.items.length} items ·{" "}
                            {o.branchName?.[lang]}
                          </small>
                        </div>
                        <span className="status">{o.status}</span>
                        <b>{money(o.total)}</b>
                        <ChevronRight size={16} />
                      </summary>
                      <div>
                        {o.estimatedDeliveryMinutes && (
                          <p>{t("estimatedDelivery")}: {o.estimatedDeliveryMinutes.join("–")} {t("deliveryMinutes")}</p>
                        )}
                        {o.items.map((i: CartItem) => (
                          <p key={i.key}>
                            {i.qty} × {(i.dish ? name(i.dish) : dishes.find((d) => d.id === i.id) ? name(dishes.find((d) => d.id === i.id)!) : t("removedDish"))}
                  <small>{cartOptions(i)}</small>{" "}
                            · {money(i.qty * i.price)}
                          </p>
                        ))}
                      </div>
                    </details>
                  ))
                ) : (
                  <div className="panel empty">
                    <ShoppingBag size={34} />
                    <Heading>No orders just yet</Heading>
                    <p>Your first Manara moment is only a few clicks away.</p>
                    <Button onClick={() => navigate("/menu")}>
                      {t("explore")}
                    </Button>
                  </div>
                )}
              </>
            ) : profileTab === "addresses" ? (
              <div className="panel">
                <Heading>{t("addresses")}</Heading>
                {addresses.map((a, i) => (
                  <div className="address-card" key={i}>
                    <MapPin size={20} />
                    <span>{a}</span>
                    <button
                      className="icon-button"
                      aria-label="Edit address"
                      onClick={() => {
                        setAddressEdit({ index: i, value: a })
                      }}
                    >
                      Edit
                    </button>
                    <button
                      className="icon-button"
                      aria-label="Remove address"
                      onClick={() =>
                        setAddresses((v) => v.filter((_, j) => j !== i))
                      }
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
                <form
                  className="auth-form"
                  onSubmit={(e) => {
                    e.preventDefault()
                    const form = e.currentTarget
                    const d = new FormData(form)
                    setAddresses((v) => [...v, String(d.get("address"))])
                    form.reset()
                    notify("Address saved")
                  }}
                >
                  <Field
                    label="Add an address"
                    name="address"
                    required
                    placeholder="Street, building, apartment, city"
                  />
                  <Button type="submit">
                    <Plus size={16} />
                    Save address
                  </Button>
                </form>
              </div>
            ) : (
              <form
                className="panel auth-form"
                onSubmit={async (e) => {
                  e.preventDefault()
                  const d = new FormData(e.currentTarget)
                  if (d.get("password") !== d.get("confirm")) {
                    notify("Passwords do not match")
                    return
                  }
                  const form = e.currentTarget
                  const account = accounts.find((entry) => entry.email === user.email)
                  if (!account) { notify(t("demoGuestPassword")); return }
                  setAuthBusy(true)
                  try {
                    const salt = crypto.randomUUID()
                    const hash = await passwordHash(String(d.get("password")), salt)
                    setAccounts((entries) => entries.map((entry) => entry.email === user.email ? { ...entry, salt, hash } : entry))
                    notify(t("passwordChanged"))
                    form.reset()
                  } catch { notify(t("errorDescription")) } finally { setAuthBusy(false) }
                }}
              >
                <Heading>{t("settings")}</Heading>
                <Field
                  label="New password"
                  name="password"
                  type="password"
                  minLength={8}
                  required
                />
                <Field
                  label="Confirm password"
                  name="confirm"
                  type="password"
                  minLength={8}
                  required
                />
                <Button type="submit" disabled={authBusy}>{authBusy ? t("working") : t("resetPassword")}</Button>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => {
                    setUser(null)
                    navigate("/login")
                  }}
                >
                  {t("logout")}
                </Button>
                <small className="muted">
                  Demo account. Do not use a real password.
                </small>
              </form>
            )}
          </div>
        </div>
      </section>
    )
  const Footer = () => (
    <footer>
      <div className="container newsletter">
        <div>
          <Heading as="h3">{t("newsletter")}</Heading>
          <p>Fresh news, special treats, and a seat at our table.</p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            const fields = formFields(e.currentTarget)
            setSubmissions((entries) => [{ id: crypto.randomUUID(), kind: "newsletter", branchId: branch.id, date: new Date().toISOString(), fields }, ...entries])
            notify(t("subscriptionSaved"))
            e.currentTarget.reset()
          }}
        >
          <input
            required
            type="email"
            name="email"
            placeholder={t("email")}
            aria-label={t("email")}
          />
          <Button type="submit">
            {t("subscribe")}
            <ArrowRight size={16} />
          </Button>
        </form>
      </div>
      <div className="container footer-grid">
        <div className="footer-brand">
          {Logo()}
          <p>{t("footerDescription")}</p>
          <div className="socials">
            <a href={site.instagram} aria-label="Instagram">
              <Instagram size={17} />
            </a>
            <a href={site.facebook} aria-label="Facebook">
              <Facebook size={17} />
            </a>
          </div>
        </div>
        <div>
          <b>Explore Manara</b>
          {[
            ["home", "/"],
            ["menu", "/menu"],
            ["about", "/about"],
            ["gallery", "/gallery"],
          ].map(([key, p]) => (
            <LocaleLink locale={lang} key={p} href={p}>
              {t(key)}
            </LocaleLink>
          ))}
        </div>
        <div>
          <b>A little help</b>
          {[
            ["contact", "/contact"],
            ["reservation", "/reservation"],
            ["profile", "/profile"],
            ["cart", "/cart"],
          ].map(([key, p]) => (
            <LocaleLink locale={lang} key={p} href={p}>
              {t(key)}
            </LocaleLink>
          ))}
        </div>
        <div>
          <b>Find your way to us</b>
          <span>
            <MapPin size={15} />
            {branch.address[lang]}
          </span>
          <a href={`tel:${branch.phone.replace(/ /g, "")}`}>
            <Phone size={15} />
            {branch.phone}
          </a>
          <a href={`mailto:${site.email}`}>
            <Mail size={15} />
            {site.email}
          </a>
          <span>
            <Clock3 size={15} />
            {branch.openingHours[lang]}
          </span>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>
          © {new Date().getFullYear()} {site.name}. A little goodness, every
          day.
        </span>
        <div>
          <LocaleLink locale={lang} href="/privacy">{t("privacy")}</LocaleLink>
          <LocaleLink locale={lang} href="/terms">{t("terms")}</LocaleLink>
        </div>
        <span>Made with care.</span>
      </div>
    </footer>
  )
  const route = () => {
    if (!hydrated && ["/cart", "/checkout", "/profile", "/login", "/signup", "/forgot-password", "/reset-password"].includes(path))
      return <div className="container section" role="status" aria-live="polite">{t("loading")}</div>
    if (path === "/") return Home()
    if (path === "/menu") return MenuPage()
    if (path.startsWith("/food/")) {
      const d = dishes.find((d) => d.id === Number(path.split("/")[2]))
      return d ? FoodPage({ dish: d }) : <>{Empty()}</>
    }
    if (path === "/cart") return CartPage()
    if (path === "/checkout") return CheckoutPage()
    if (path === "/gallery") return GalleryPage()
    if (path === "/contact" || path === "/reservation")
      return ContactPage({ reservation: path === "/reservation" })
    if (["/login", "/signup", "/forgot-password", "/reset-password"].includes(path))
      return AuthPage()
    if (path === "/profile") return ProfilePage()
    return (
      <section className="container section empty">
        <Heading>Page not found</Heading>
        <Button onClick={() => navigate("/")}>{t("backHome")}</Button>
      </section>
    )
  }

  return (
    <LanguageContext.Provider value={lang}><PageContext.Provider value={route}>
    <div
      className="app-shell"
      style={
        {
          "--primary": site.colors.primary,
          "--secondary": site.colors.secondary,
          "--font-en": site.fonts.en,
          "--font-ar": site.fonts.ar,
        } as CSSProperties
      }
    >
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <header className="header h-auto">
        <div className="container nav flex-wrap gap-y-3 py-3">
          <LocaleLink locale={lang} href="/" className="logo-link">
            {Logo()}
          </LocaleLink>
          <nav
            className="desktop-nav order-3 w-full justify-center xl:order-none xl:w-auto"
            aria-label="Main navigation"
          >
            {[
              ["home", "/"],
              ["menu", "/menu"],
              ["about", "/about"],
              ["gallery", "/gallery"],
              ["contact", "/contact"],
            ].map(([k, p]) => (
              <LocaleLink locale={lang} key={p} href={p} className={path === p ? "active" : ""} aria-current={path === p ? "page" : undefined}>
                {t(k)}
              </LocaleLink>
            ))}
          </nav>
          <div className="nav-actions">
            {branchSelector(true)}
            <Button
              variant="ghost"
              className="language"
              onClick={() => {
                // Locale rewrites share an internal route; fetch fresh server metadata.
                window.location.assign(localizedPath(path + window.location.search, lang === "en" ? "ar" : "en"))
              }}
              aria-label="Switch language"
            >
              <Globe2 size={16} />
              {lang === "en" ? "العربية" : "English"}
            </Button>
            <span className="nav-divider" />
            <Button
              className="nav-reserve"
              onClick={() => navigate("/reservation")}
            >
              {t("reservation")}
              <ArrowUpRight size={15} />
            </Button>
            <button
              className="icon-button cart-button"
              onClick={() => navigate("/cart")}
              aria-label={`Cart, ${count} items`}
            >
              <ShoppingBag size={20} />
              {count > 0 && <span className="cart-count">{count}</span>}
            </button>
            <button
              className="icon-button account-button"
              onClick={() => navigate(user ? "/profile" : "/login")}
              aria-label="My account"
            >
              <UserRound size={20} />
            </button>
            <button
              className="icon-button mobile-menu"
              onClick={() => setMobile(true)}
              aria-label="Open navigation"
            >
              <MenuIcon size={23} />
            </button>
          </div>
        </div>
      </header>
      <Dialog.Root open={mobile} onOpenChange={setMobile}>
        <Dialog.Portal>
          <Dialog.Overlay className="modal-overlay" />
          <Dialog.Content className="mobile-drawer">
            <Dialog.Title>
              {Logo()}
            </Dialog.Title>
            <Dialog.Description className="sr-only">
              Browse Manara
            </Dialog.Description>
            <Dialog.Close
              className="dialog-close"
              aria-label="Close navigation"
            >
              <X />
            </Dialog.Close>
            <nav>
              {[
                ["home", "/"],
                ["menu", "/menu"],
                ["about", "/about"],
                ["gallery", "/gallery"],
                ["contact", "/contact"],
                ["reservation", "/reservation"],
                ["profile", user ? "/profile" : "/login"],
              ].map(([k, p]) => (
                <LocaleLink locale={lang} key={p} href={p}>
                  {t(k)}
                  <ArrowUpRight size={18} />
                </LocaleLink>
              ))}
            </nav>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
      <main id="main" tabIndex={-1}>{children}</main>
      {Footer()}
      {count > 0 && !["/cart", "/checkout"].includes(path) && (
        <button className="mobile-cart-bar" onClick={() => navigate("/cart")}>
          <ShoppingBag size={19} />
          <span>View cart · {count} items</span>
          <b>{money(subtotal)}</b>
          <ArrowRight size={18} />
        </button>
      )}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={19} />
          {toast}
          <button
            onClick={() => setToast("")}
            aria-label="Dismiss notification"
          >
            <X size={15} />
          </button>
        </div>
      )}
      <Dialog.Root open={addressEdit !== null} onOpenChange={(open) => { if (!open) setAddressEdit(null) }}>
        <Dialog.Portal><Dialog.Overlay className="modal-overlay" /><Dialog.Content className="address-dialog panel">
          <Dialog.Title>{t("editAddress")}</Dialog.Title>
          <Dialog.Description>{t("editAddressDescription")}</Dialog.Description>
          <form className="auth-form" onSubmit={(event) => {
            event.preventDefault()
            if (!addressEdit?.value.trim()) return
            setAddresses((entries) => entries.map((entry, index) => index === addressEdit.index ? addressEdit.value.trim() : entry))
            setAddressEdit(null)
          }}>
            <Field label={t("address")} required value={addressEdit?.value ?? ""} onChange={(event) => setAddressEdit((current) => current ? { ...current, value: event.target.value } : null)} />
            <Button type="submit">{t("saveAddress")}</Button>
            <Dialog.Close asChild><Button variant="outline">{t("cancel")}</Button></Dialog.Close>
          </form>
        </Dialog.Content></Dialog.Portal>
      </Dialog.Root>
      <Dialog.Root
        open={!!lightbox}
        onOpenChange={(open) => !open && setLightbox(null)}
      >
        <Dialog.Portal>
          <Dialog.Overlay className="modal-overlay" />
          <Dialog.Content className="lightbox">
            <Dialog.Title className="sr-only">Manara photo</Dialog.Title>
            <Dialog.Description className="sr-only">
              Full-size gallery photograph
            </Dialog.Description>
            <Dialog.Close className="dialog-close" aria-label="Close photo">
              <X />
            </Dialog.Close>
            {lightbox && <Image asset={lightbox} lang={lang} size="lightbox" loading="eager" />}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
    </PageContext.Provider></LanguageContext.Provider>
  )
}
