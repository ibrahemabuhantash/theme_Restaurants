import type { ImgHTMLAttributes } from "react"
import { imageSizes, responsiveSources, type ImageAsset } from "../config/images"

type Props = Omit<ImgHTMLAttributes<HTMLImageElement>, "src" | "srcSet" | "alt" | "sizes" | "width" | "height"> & {
  asset: ImageAsset
  lang: "en" | "ar"
  size: keyof typeof imageSizes
  decorative?: boolean
}

export default function Image({
  asset, lang, size, decorative = false, loading = "lazy", ...props
}: Props) {
  return (
    <img
      {...props}
      src={asset.src}
      alt={decorative ? "" : asset.alt[lang]}
      width={asset.width}
      height={asset.height}
      srcSet={responsiveSources(asset)}
      sizes={imageSizes[size]}
      loading={loading}
      decoding="async"
    />
  )
}
