import { routeMetadata } from "../../lib/server-seo"
import InteractivePage from "../../components/InteractivePage"

export async function generateMetadata() {
  return routeMetadata("/login", "login")
}

export default function Page() {
  return <InteractivePage />
}
