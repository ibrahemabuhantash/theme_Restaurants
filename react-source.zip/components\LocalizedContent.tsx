"use client"

import type { ReactNode } from "react"
import { useLanguage } from "../lib/language-context"

export default function LocalizedContent({ english, arabic }: { english: ReactNode; arabic: ReactNode }) {
  return <>{useLanguage() === "ar" ? arabic : english}</>
}
