import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
} from "react"
export function Select({
  label,
  options,
  className = "",
  ...props
}: SelectHTMLAttributes<HTMLSelectElement> & {
  label: string
  options: { value: string; label: string }[]
}) {
  return (
    <label className={`field ${className}`}>
      <span>{label}</span>
      <select aria-label={props["aria-label"] ?? label} {...props}>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </label>
  )
}
export function Button({
  children,
  variant = "primary",
  className = "",
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "outline" | "ghost"
  children: ReactNode
}) {
  return (
    <button type={type} className={`btn btn-${variant} ${className}`} {...props}>
      {children}
    </button>
  )
}
export function Field({
  label,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="field">
      <span>{label}</span>
      <input name={props.name ?? label.toLowerCase().replace(/\s+/g, "-")} {...props} />
    </label>
  )
}
export function Heading({
  children,
  as = "h2",
  className = "",
}: {
  children: ReactNode
  as?: "h1" | "h2" | "h3"
  className?: string
}) {
  const Tag = as
  return <Tag className={className}>{children}</Tag>
}
